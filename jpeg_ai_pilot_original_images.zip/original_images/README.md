# Pilot Study Test Images — Original Resolution

These are the 24 real images used in the paper's extended pilot feasibility
study (Section 5, Tables 1–3), provided here at their **native/original
resolution**, losslessly encoded as PNG. In the paper and in the reference
implementation's pilot scripts these are center-cropped/resized to 256×256
before use (`load_image_square()` in `core.py`); the files here are the
un-cropped, un-resized originals.

## Provenance

All 24 images are the standard sample images bundled with the
**scikit-image** Python library (`skimage.data`), a widely used, permissively
licensed (BSD-3-Clause) open-source image-processing package. They are
standard, freely distributable computer-vision test images spanning natural
photographs, grayscale test images, biomedical microscopy, and astronomical
imagery — chosen for the pilot study precisely because they are public,
citable, and reproducible by anyone with `pip install scikit-image`, rather
than a private or ad hoc image set.

For authoritative per-image provenance and licensing detail (photographer/
source credit where applicable), see the scikit-image documentation:
https://scikit-image.org/docs/stable/api/skimage.data.html

Each image can be regenerated directly with, e.g.:

```python
from skimage import data
img = data.astronaut()   # -> the same array these PNGs were saved from
```

## Manifest

| # | File | Name | Width | Height | Mode |
|---|------|------|-------|--------|------|
1 | astronaut.png | astronaut | 512 | 512 | RGB
2 | camera.png | camera | 512 | 512 | L (grayscale)
3 | cat.png | cat | 451 | 300 | RGB
4 | chelsea.png | chelsea | 451 | 300 | RGB
5 | coffee.png | coffee | 600 | 400 | RGB
6 | coins.png | coins | 384 | 303 | L (grayscale)
7 | horse.png | horse | 400 | 328 | L (grayscale)
8 | hubble_deep_field.png | hubble_deep_field | 1000 | 872 | RGB
9 | moon.png | moon | 512 | 512 | L (grayscale)
10 | page.png | page | 384 | 191 | L (grayscale)
11 | rocket.png | rocket | 640 | 427 | RGB
12 | brick.png | brick | 512 | 512 | L (grayscale)
13 | grass.png | grass | 512 | 512 | L (grayscale)
14 | gravel.png | gravel | 512 | 512 | L (grayscale)
15 | checkerboard.png | checkerboard | 200 | 200 | L (grayscale)
16 | clock.png | clock | 400 | 300 | L (grayscale)
17 | immunohistochemistry.png | immunohistochemistry | 512 | 512 | RGB
18 | retina.png | retina | 1411 | 1411 | RGB
19 | text.png | text | 448 | 172 | L (grayscale)
20 | colorwheel.png | colorwheel | 371 | 370 | RGB
21 | cell.png | cell | 550 | 660 | L (grayscale)
22 | microaneurysms.png | microaneurysms | 102 | 102 | L (grayscale)
23 | shepp_logan_phantom.png | shepp_logan_phantom | 400 | 400 | L (grayscale)
24 | binary_blobs.png | binary_blobs | 512 | 512 | L (grayscale)

(Machine-readable version: `manifest.json` in this same folder.)

## Note on grayscale images

15 of the 24 images are natively single-channel (grayscale) and 9 are RGB.
The pilot
pipeline's `load_image_square()` converts every image to RGB (replicating
the single channel across R, G, B) before compression, tampering, and PSNR
computation — matching how `skimage.color.gray2rgb` was used in the
original pilot scripts and how the browser interface's `<canvas>` handles
grayscale uploads. If you re-run the pipeline directly on the files in this
folder, apply the same RGB conversion first for results consistent with the
paper.

## Reproducing the paper's crop

To reproduce the exact 256×256 inputs used in Tables 1–3 from these
originals:

```python
from jpeg_ai_forensic_pilot import load_image_square
img_256 = load_image_square("astronaut.png")   # cover-fit crop to 256x256
```
